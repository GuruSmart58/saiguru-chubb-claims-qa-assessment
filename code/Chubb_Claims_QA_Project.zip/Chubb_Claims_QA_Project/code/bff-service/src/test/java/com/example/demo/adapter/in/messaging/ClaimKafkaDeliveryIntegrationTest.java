package com.example.demo.adapter.in.messaging;

import com.example.demo.adapter.in.websocket.ClaimWebSocketHandler;
import com.example.demo.adapter.in.websocket.WebSocketMessage;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.kafka.test.utils.KafkaTestUtils;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

/** Real broker + production @KafkaListener; WebSocket transport boundary mocked. */
@Tag("integration")
@SpringJUnitConfig(ClaimKafkaDeliveryIntegrationTest.KafkaConfig.class)
@EmbeddedKafka(partitions = 1, topics = {"claim-events", "cdc.demo-app.public.claims"})
@DirtiesContext
class ClaimKafkaDeliveryIntegrationTest {
    @Autowired private KafkaTemplate<String, String> template;
    @Autowired private ClaimWebSocketHandler handler;

    @Test
    void brokerDeliversStatusChangeToProductionListener() throws Exception {
        template.send("claim-events", "claim-001", """
            {"eventType":"claim-status-changed","eventId":"broker-event-001","payload":{
              "claimId":"claim-001","userId":"owner-001","oldStatus":"SUBMITTED","newStatus":"UNDER_REVIEW"}}
            """).get(10, TimeUnit.SECONDS);
        ArgumentCaptor<WebSocketMessage> message = ArgumentCaptor.forClass(WebSocketMessage.class);
        verify(handler, timeout(15_000).times(1)).broadcastToUserAndAdmins(eq("owner-001"), message.capture());
        assertThat(message.getValue().claimId()).isEqualTo("claim-001");
        assertThat(message.getValue().newStatus()).isEqualTo("UNDER_REVIEW");
        assertThat(message.getValue().correlationId()).isEqualTo("broker-event-001");
    }

    @Configuration
    @EnableKafka
    static class KafkaConfig {
        @Bean ClaimWebSocketHandler webSocketHandler() { return mock(ClaimWebSocketHandler.class); }
        @Bean ClaimEventKafkaConsumer eventConsumer(ClaimWebSocketHandler handler) {
            return new ClaimEventKafkaConsumer(handler, new ObjectMapper().findAndRegisterModules());
        }
        @Bean ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory(EmbeddedKafkaBroker broker) {
            var properties = KafkaTestUtils.consumerProps("bff-websocket-consumer-group", "false", broker);
            properties.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
            var factory = new ConcurrentKafkaListenerContainerFactory<String, String>();
            factory.setConsumerFactory(new DefaultKafkaConsumerFactory<>(properties, new StringDeserializer(), new StringDeserializer()));
            return factory;
        }
        @Bean KafkaTemplate<String, String> kafkaTemplate(EmbeddedKafkaBroker broker) {
            var properties = KafkaTestUtils.producerProps(broker);
            properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
            properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
            return new KafkaTemplate<>(new DefaultKafkaProducerFactory<>(properties));
        }
    }
}
