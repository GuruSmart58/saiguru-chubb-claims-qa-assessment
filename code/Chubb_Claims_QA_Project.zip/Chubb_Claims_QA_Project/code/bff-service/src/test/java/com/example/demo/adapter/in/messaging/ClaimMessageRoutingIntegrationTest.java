package com.example.demo.adapter.in.messaging;

import com.example.demo.adapter.in.messaging.ClaimEventKafkaConsumer;
import com.example.demo.adapter.in.websocket.ClaimWebSocketHandler;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketMessage;
import org.springframework.web.socket.WebSocketSession;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

/** Real event parsing and recipient routing; transport is mocked, no broker. */
@Tag("integration")
class ClaimMessageRoutingIntegrationTest {
    private final ObjectMapper mapper = new ObjectMapper().findAndRegisterModules();
    private ClaimEventKafkaConsumer consumer;
    private ClaimWebSocketHandler handler;
    private WebSocketSession owner;
    private WebSocketSession unrelated;
    private WebSocketSession admin;

    @BeforeEach
    void connectDistinctRecipients() {
        handler = new ClaimWebSocketHandler(mapper);
        consumer = new ClaimEventKafkaConsumer(handler, mapper);
        owner = session("owner", List.of("claimant"));
        unrelated = session("unrelated", List.of("claimant"));
        admin = session("admin", List.of("admin"));
    }

    private WebSocketSession session(String userId, List<String> roles) {
        WebSocketSession session = mock(WebSocketSession.class);
        when(session.getId()).thenReturn(userId + "-session");
        when(session.getAttributes()).thenReturn(Map.of("userId", userId, "userRoles", roles));
        when(session.isOpen()).thenReturn(true);
        handler.afterConnectionEstablished(session);
        return session;
    }

    @Test
    void statusChangeReachesOwnerAndAdminButNeverAnotherClaimant() throws Exception {
        consumer.consumeDomainEvent("""
            {"eventType":"claim-status-changed","eventId":"event-001","payload":{
              "claimId":"claim-001","userId":"owner","oldStatus":"SUBMITTED","newStatus":"UNDER_REVIEW"}}
            """);
        assertStatusMessage(owner);
        assertStatusMessage(admin);
        verify(unrelated, never()).sendMessage(any());
    }

    private void assertStatusMessage(WebSocketSession recipient) throws Exception {
        ArgumentCaptor<WebSocketMessage<?>> message = ArgumentCaptor.forClass(WebSocketMessage.class);
        verify(recipient, times(1)).sendMessage(message.capture());
        assertThat(message.getValue()).isInstanceOf(TextMessage.class);
        var payload = mapper.readTree(((TextMessage) message.getValue()).getPayload());
        assertThat(payload.path("type").asText()).isEqualTo("CLAIM_STATUS_CHANGED");
        assertThat(payload.path("claimId").asText()).isEqualTo("claim-001");
        assertThat(payload.path("oldStatus").asText()).isEqualTo("SUBMITTED");
        assertThat(payload.path("newStatus").asText()).isEqualTo("UNDER_REVIEW");
        assertThat(payload.path("correlationId").asText()).isEqualTo("event-001");
    }

    @Test
    void submittedClaimNotifiesOnlyAdmins() throws Exception {
        consumer.consumeDomainEvent("""
            {"eventType":"claim-submitted","eventId":"submitted-001","payload":{"claimId":"claim-001","userId":"owner"}}
            """);
        verify(admin, times(1)).sendMessage(any(TextMessage.class));
        verify(owner, never()).sendMessage(any());
        verify(unrelated, never()).sendMessage(any());
    }

    @Test
    void malformedOrUnknownEventsDoNotBroadcast() throws Exception {
        consumer.consumeDomainEvent("not-json");
        consumer.consumeDomainEvent("{\"eventType\":\"unknown\",\"payload\":{}}");
        verify(owner, never()).sendMessage(any());
        verify(admin, never()).sendMessage(any());
        verify(unrelated, never()).sendMessage(any());
    }

    @Test
    void closedOwnerConnectionDoesNotPreventAdminDelivery() throws Exception {
        when(owner.isOpen()).thenReturn(false);
        consumer.consumeDomainEvent("""
            {"eventType":"claim-status-changed","eventId":"event-001","payload":{
              "claimId":"claim-001","userId":"owner","oldStatus":"SUBMITTED","newStatus":"UNDER_REVIEW"}}
            """);
        verify(owner, never()).sendMessage(any());
        assertStatusMessage(admin);
    }
}
