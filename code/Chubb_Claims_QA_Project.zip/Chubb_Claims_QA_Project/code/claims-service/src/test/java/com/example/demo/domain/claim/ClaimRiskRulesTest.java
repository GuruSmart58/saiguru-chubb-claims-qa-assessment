package com.example.demo.domain.claim;

import com.example.demo.domain.claim.Claim;
import com.example.demo.domain.claim.ClaimStatus;
import com.example.demo.domain.claim.InvalidClaimException;
import com.example.demo.domain.claim.InvalidStatusTransitionException;
import com.example.demo.domain.claim.events.ClaimStatusChanged;
import com.example.demo.fixtures.ClaimTestBuilder;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ClaimRiskRulesTest {
    @ParameterizedTest(name = "{0} -> {1}: allowed={2}")
    @CsvSource({
        "SUBMITTED,SUBMITTED,false", "SUBMITTED,UNDER_REVIEW,true", "SUBMITTED,APPROVED,false",
        "SUBMITTED,REJECTED,true", "SUBMITTED,CLOSED,false",
        "UNDER_REVIEW,SUBMITTED,true", "UNDER_REVIEW,UNDER_REVIEW,false", "UNDER_REVIEW,APPROVED,true",
        "UNDER_REVIEW,REJECTED,true", "UNDER_REVIEW,CLOSED,false",
        "APPROVED,SUBMITTED,false", "APPROVED,UNDER_REVIEW,false", "APPROVED,APPROVED,false",
        "APPROVED,REJECTED,false", "APPROVED,CLOSED,true",
        "REJECTED,SUBMITTED,false", "REJECTED,UNDER_REVIEW,false", "REJECTED,APPROVED,false",
        "REJECTED,REJECTED,false", "REJECTED,CLOSED,true",
        "CLOSED,SUBMITTED,false", "CLOSED,UNDER_REVIEW,false", "CLOSED,APPROVED,false",
        "CLOSED,REJECTED,false", "CLOSED,CLOSED,false"
    })
    void transitionMatrixChangesOnlyPermittedStates(ClaimStatus from, ClaimStatus to, boolean allowed) {
        Instant persistedTime = Instant.parse("2020-01-16T00:00:00Z");
        Claim claim = Claim.reconstitute(UUID.randomUUID(), UUID.randomUUID(),
                LocalDate.of(2020, 1, 15), "Central Road", "Vehicle damage on the road",
                new BigDecimal("2500.50"), from, persistedTime, persistedTime);
        if (allowed) {
            claim.updateStatus(to);
            assertThat(claim.getStatus()).isEqualTo(to);
            assertThat(claim.getDomainEvents()).hasSize(1);
            ClaimStatusChanged event = (ClaimStatusChanged) claim.getDomainEvents().getFirst();
            assertThat(event.oldStatus()).isEqualTo(from);
            assertThat(event.newStatus()).isEqualTo(to);
            assertThat(event.claimId()).isEqualTo(claim.getClaimId());
        } else {
            assertThatThrownBy(() -> claim.updateStatus(to)).isInstanceOf(InvalidStatusTransitionException.class);
            assertThat(claim.getStatus()).isEqualTo(from);
            assertThat(claim.getUpdatedAt()).isEqualTo(persistedTime);
            assertThat(claim.getDomainEvents()).isEmpty();
        }
    }

    @ParameterizedTest
    @ValueSource(strings = {"0.01", "1000000.00"})
    void acceptsInclusiveMonetaryBoundaries(String amount) {
        Claim claim = ClaimTestBuilder.aClaim().withClaimAmount(new BigDecimal(amount)).build();
        assertThat(claim.getClaimAmount()).isEqualByComparingTo(amount);
    }

    @ParameterizedTest
    @ValueSource(strings = {"0", "-0.01", "1000000.01"})
    void rejectsAmountsOutsideDomainRange(String amount) {
        assertThatThrownBy(() -> ClaimTestBuilder.aClaim().withClaimAmount(new BigDecimal(amount)).build())
                .isInstanceOf(InvalidClaimException.class);
    }

    @Test
    void rejectsDescriptionThatOnlyMeetsMinimumBeforeTrimming() {
        assertThatThrownBy(() -> ClaimTestBuilder.aClaim().withDescription("          ").build())
                .isInstanceOf(InvalidClaimException.class);
    }

    @Test
    void rejectsLocationThatOnlyMeetsMinimumBeforeTrimming() {
        assertThatThrownBy(() -> ClaimTestBuilder.aClaim().withIncidentLocation("     ").build())
                .isInstanceOf(InvalidClaimException.class);
    }

    @Test
    void rejectsFutureIncidentDate() {
        assertThatThrownBy(() -> ClaimTestBuilder.aClaim().withIncidentDate(LocalDate.now().plusDays(1)).build())
                .isInstanceOf(InvalidClaimException.class);
    }
}
