import { test, expect } from './support/fixtures';

test('created claim is persisted and appears only in its owner list', async ({ claimant, otherClaimant }) => {
  const claim = await claimant.createClaim();
  const detail = await claimant.get(claim.claimId);
  await expect(detail).toBeOK();
  expect(await detail.json()).toMatchObject({ claimId: claim.claimId, userId: claimant.userId, claimAmount: 2500.5 });
  const ownerList = await claimant.list();
  await expect(ownerList).toBeOK();
  expect(await ownerList.json()).toEqual(expect.arrayContaining([expect.objectContaining({ claimId: claim.claimId })]));
  const otherList = await otherClaimant.list();
  await expect(otherList).toBeOK();
  expect(await otherList.json()).not.toEqual(expect.arrayContaining([expect.objectContaining({ claimId: claim.claimId })]));
  expect((await otherClaimant.get(claim.claimId)).status()).toBe(403);
});

test('claimants cannot invoke admin status updates even with valid CSRF', async ({ claimant }) => {
  const claim = await claimant.createClaim();
  expect((await claimant.status(claim.claimId, 'UNDER_REVIEW')).status()).toBe(403);
  const detail = await claimant.get(claim.claimId);
  await expect(detail).toBeOK();
  expect((await detail.json()).status).toBe('SUBMITTED');
});

test('admin completes lifecycle and illegal transitions leave persisted status unchanged', async ({ claimant, admin }) => {
  const claim = await claimant.createClaim();
  expect((await admin.status(claim.claimId, 'APPROVED')).status()).toBe(400);
  for (const newStatus of ['UNDER_REVIEW', 'APPROVED', 'CLOSED']) {
    const update = await admin.status(claim.claimId, newStatus);
    await expect(update).toBeOK();
    expect((await update.json()).status).toBe(newStatus);
    const detail = await claimant.get(claim.claimId);
    await expect(detail).toBeOK();
    expect((await detail.json()).status).toBe(newStatus);
  }
  expect((await admin.status(claim.claimId, 'UNDER_REVIEW')).status()).toBe(400);
  expect((await (await claimant.get(claim.claimId)).json()).status).toBe('CLOSED');
});

for (const claimAmount of [0, -0.01, 1000000.01]) {
  test(`rejects amount ${claimAmount} without persisting a claim`, async ({ claimant }) => {
    expect((await claimant.submit({ claimAmount })).status()).toBe(400);
    const list = await claimant.list();
    await expect(list).toBeOK();
    expect(await list.json()).toEqual([]);
  });
}

test('missing CSRF token prevents a claim write', async ({ claimant }) => {
  const response = await claimant.api.post('/api/claims', { data: {
    incidentDate: '2020-01-15', incidentLocation: 'Hyderabad Road',
    description: 'Vehicle damage from incident', claimAmount: 50,
  } });
  expect(response.status()).toBe(403);
  const list = await claimant.list();
  await expect(list).toBeOK();
  expect(await list.json()).toEqual([]);
});

test('anonymous callers cannot list claims', async ({ request }) => {
  const base = process.env.QA_BFF_URL || 'http://localhost:8090';
  expect((await request.get(`${base}/api/claims`)).status()).toBe(401);
});
