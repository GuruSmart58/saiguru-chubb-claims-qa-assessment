import { randomUUID } from 'node:crypto';
import { test, expect } from './support/fixtures';
import { ClaimsPage } from './support/claims-page';

test('claimant submits through UI and reads the persisted claim through the API', async ({ page, claimant, credentials }) => {
  // Fixture really registers the user; the browser really logs in. No mocked routes.
  const ui = new ClaimsPage(page);
  await ui.login(credentials);
  const description = `QA incident ${randomUUID()}`;
  const claim = await ui.submit(description);
  expect(claim.userId).toBe(claimant.userId);
  const detail = await claimant.get(claim.claimId);
  await expect(detail).toBeOK();
  expect(await detail.json()).toMatchObject({ claimId: claim.claimId, description, claimAmount: 2500.5 });
  const row = page.getByRole('row').filter({ hasText: description });
  await expect(row).toContainText('Submitted');
  await row.getByRole('button', { name: 'View Details' }).click();
  await expect(page.getByRole('dialog')).toContainText(claim.claimId);
});

test('Kafka status event updates the claimant page without reloading', async ({ page, claimant, credentials, admin }) => {
  const claim = await claimant.createClaim();
  const ui = new ClaimsPage(page);
  // Install before logging in so the real application WebSocket is captured.
  const socket = page.waitForEvent('websocket', { predicate: (ws) => ws.url().includes('/api/ws/claims') });
  await ui.login(credentials);
  const connection = await socket;
  await expect(page.getByRole('status', { name: 'Connection status: Live' })).toBeVisible();
  const frame = connection.waitForEvent('framereceived', { predicate: ({ payload }) => {
    try {
      const data = JSON.parse(String(payload));
      return data.type === 'CLAIM_STATUS_CHANGED' && data.claimId === claim.claimId && data.newStatus === 'UNDER_REVIEW';
    } catch { return false; }
  } });
  const response = await admin.status(claim.claimId, 'UNDER_REVIEW');
  await expect(response).toBeOK();
  await frame;
  await expect(page.getByRole('row').filter({ hasText: claim.claimId.substring(0, 8) })).toContainText('Under Review');
});

test('protected UI redirects anonymous visitors to login', async ({ page }) => {
  await page.goto('/claims/new');
  await expect(page).toHaveURL(/\/login\?redirect=/);
});
