import { request } from '@playwright/test';

export default async function globalSetup() {
  const api = await request.newContext({ baseURL: process.env.QA_BFF_URL || 'http://localhost:8090' });
  try {
    const response = await api.get('/actuator/health', { timeout: 10_000 });
    if (!response.ok() || (await response.json()).status !== 'UP') {
      throw new Error(`BFF health check failed: ${response.status()}. Start the complete Compose stack first.`);
    }
  } catch (error) {
    throw new Error('Full stack unavailable. Follow qa/README.md before running E2E.', { cause: error });
  } finally { await api.dispose(); }
}
