import { expect, type APIRequestContext, type APIResponse } from '@playwright/test';
import { randomUUID } from 'node:crypto';

export const validClaim = {
  incidentDate: '2020-01-15', incidentLocation: 'Hyderabad Central Road',
  description: 'Vehicle damage during a road incident', claimAmount: 2500.5,
};
export type Credentials = { email: string; password: string };
export function uniqueCredentials(): Credentials {
  return { email: `qa-${randomUUID()}@example.com`, password: 'QaSecure123!' };
}
export class ClaimsClient {
  private csrfHeaders: Record<string, string> = {};
  userId = '';
  constructor(readonly api: APIRequestContext) {}

  async register(credentials: Credentials) {
    const response = await this.api.post('/api/auth/signup', { data: { ...credentials, name: 'QA Claimant' } });
    await expect(response).toBeOK();
    expect(response.status()).toBe(201);
    return this.login(credentials);
  }
  async login(credentials: Credentials) {
    const response = await this.api.post('/api/auth/login', { data: credentials });
    await expect(response).toBeOK();
    this.userId = (await response.json()).userId;
    const csrf = await this.api.get('/api/auth/csrf');
    await expect(csrf).toBeOK();
    const token = await csrf.json();
    expect(token.token).toBeTruthy();
    this.csrfHeaders = { [token.headerName]: token.token };
  }
  submit(data: Partial<typeof validClaim> = {}): Promise<APIResponse> {
    return this.api.post('/api/claims', { data: { ...validClaim, ...data }, headers: this.csrfHeaders });
  }
  async createClaim() {
    const response = await this.submit();
    await expect(response).toBeOK();
    expect(response.status()).toBe(201);
    const claim = await response.json();
    expect(claim.userId).toBe(this.userId);
    expect(claim.status).toBe('SUBMITTED');
    expect(claim.claimAmount).toBe(validClaim.claimAmount);
    return claim;
  }
  get(id: string) { return this.api.get(`/api/claims/${id}`); }
  list() { return this.api.get('/api/claims'); }
  status(id: string, newStatus: string) {
    return this.api.patch(`/api/admin/claims/${id}/status`, { data: { newStatus }, headers: this.csrfHeaders });
  }
}
