import { expect, type Page } from '@playwright/test';
import type { Credentials } from './claims-client';
import { validClaim } from './claims-client';

export class ClaimsPage {
  constructor(readonly page: Page) {}
  async login(credentials: Credentials) {
    await this.page.goto('/login');
    await this.page.getByLabel('Email', { exact: true }).fill(credentials.email);
    await this.page.getByLabel('Password', { exact: true }).fill(credentials.password);
    await this.page.getByRole('button', { name: 'Log In', exact: true }).click();
    await expect(this.page).toHaveURL(/\/claims$/);
  }
  async submit(description: string) {
    await this.page.goto('/claims/new');
    await this.page.getByLabel(/When did the incident occur/).fill(validClaim.incidentDate);
    await this.page.getByLabel(/Where did the incident occur/).fill(validClaim.incidentLocation);
    await this.page.getByLabel(/Claim Amount/).fill(String(validClaim.claimAmount));
    await this.page.getByRole('button', { name: 'Next', exact: true }).click();
    await this.page.getByLabel(/Describe what happened/).fill(description);
    await this.page.getByRole('button', { name: 'Next', exact: true }).click();
    await expect(this.page.getByRole('heading', { name: 'Review Your Claim' })).toBeVisible();
    const response = this.page.waitForResponse((r) => r.url().endsWith('/api/claims') && r.request().method() === 'POST');
    await this.page.getByRole('button', { name: 'Submit Claim', exact: true }).click();
    const saved = await response;
    expect(saved.status()).toBe(201);
    await expect(this.page).toHaveURL(/\/claims$/);
    return saved.json();
  }
}
