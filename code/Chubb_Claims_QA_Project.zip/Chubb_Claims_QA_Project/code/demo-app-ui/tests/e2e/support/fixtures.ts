import { test as base, request, expect } from '@playwright/test';
import { ClaimsClient, uniqueCredentials, type Credentials } from './claims-client';

export const test = base.extend<{
  claimant: ClaimsClient; otherClaimant: ClaimsClient; admin: ClaimsClient; credentials: Credentials;
}>({
  credentials: async ({}, use) => { await use(uniqueCredentials()); },
  claimant: async ({ credentials }, use) => {
    const api = await request.newContext({ baseURL: process.env.QA_BFF_URL || 'http://localhost:8090' });
    try { const client = new ClaimsClient(api); await client.register(credentials); await use(client); }
    finally { await api.dispose(); }
  },
  otherClaimant: async ({}, use) => {
    const api = await request.newContext({ baseURL: process.env.QA_BFF_URL || 'http://localhost:8090' });
    try { const client = new ClaimsClient(api); await client.register(uniqueCredentials()); await use(client); }
    finally { await api.dispose(); }
  },
  admin: async ({}, use) => {
    const api = await request.newContext({ baseURL: process.env.QA_BFF_URL || 'http://localhost:8090' });
    try {
      const client = new ClaimsClient(api);
      await client.login({ email: process.env.QA_ADMIN_EMAIL || 'admin@demo.com', password: process.env.QA_ADMIN_PASSWORD || 'Admin123!' });
      await use(client);
    } finally { await api.dispose(); }
  },
});
export { expect };
