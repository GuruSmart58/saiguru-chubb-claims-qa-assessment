import { afterEach, expect, it, vi } from 'vitest';

afterEach(() => { vi.unstubAllEnvs(); vi.unstubAllGlobals(); vi.resetModules(); });
it('local API requests default to the BFF port rather than the claims service port', async () => {
  vi.stubEnv('NEXT_PUBLIC_BFF_URL', undefined);
  vi.stubEnv('USE_WIREMOCK_BFF', undefined);
  vi.resetModules();
  const fetch = vi.fn().mockResolvedValue(new Response('[]', { status: 200 }));
  vi.stubGlobal('fetch', fetch);
  const { claimsApi } = await import('@/src/lib/api/bff-client');
  await claimsApi.listClaims();
  expect(fetch.mock.calls[0][0]).toBe('http://localhost:8090/api/claims');
});
