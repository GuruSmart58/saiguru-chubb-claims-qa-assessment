import type { ClaimResponse } from '@/src/lib/api/bff-client';

export const claimInput = {
  incidentDate: new Date('2020-01-15T00:00:00Z'),
  incidentLocation: 'Hyderabad Central Road',
  description: 'Vehicle damage during a road incident',
  claimAmount: 2500.5,
};
export const savedClaim: ClaimResponse = {
  ...claimInput,
  claimId: '660e8400-e29b-41d4-a716-446655440001',
  userId: '550e8400-e29b-41d4-a716-446655440001',
  status: 'SUBMITTED',
  createdAt: new Date('2020-01-16T00:00:00Z'),
  updatedAt: new Date('2020-01-16T00:00:00Z'),
};
export function deferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((res) => { resolve = res; });
  return { promise, resolve };
}
