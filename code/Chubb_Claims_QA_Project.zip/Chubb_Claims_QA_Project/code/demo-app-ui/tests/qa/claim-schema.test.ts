import { beforeEach, afterEach, describe, expect, it, vi } from 'vitest';
import { claimSubmissionSchema } from '@/src/features/claims/schemas/claim-schemas';
import { claimInput } from './claim-fixture';

describe('Claim submission boundaries', () => {
  beforeEach(() => { vi.useFakeTimers(); vi.setSystemTime(new Date('2026-06-01T12:00:00Z')); });
  afterEach(() => vi.useRealTimers());
  it.each([0.01, 1000000])('accepts amount boundary %s', (claimAmount) => {
    expect(claimSubmissionSchema.safeParse({ ...claimInput, claimAmount }).success).toBe(true);
  });
  it.each([0, -0.01, 1000000.01, NaN, Infinity])('rejects invalid amount %s', (claimAmount) => {
    expect(claimSubmissionSchema.safeParse({ ...claimInput, claimAmount }).success).toBe(false);
  });
  it.each([9, 1001])('rejects description length %s', (length) => {
    expect(claimSubmissionSchema.safeParse({ ...claimInput, description: 'x'.repeat(length) }).success).toBe(false);
  });
  it.each([10, 1000])('accepts description length %s', (length) => {
    expect(claimSubmissionSchema.safeParse({ ...claimInput, description: 'x'.repeat(length) }).success).toBe(true);
  });
  it.each([4, 201])('rejects location length %s', (length) => {
    expect(claimSubmissionSchema.safeParse({ ...claimInput, incidentLocation: 'x'.repeat(length) }).success).toBe(false);
  });
  it('rejects a future incident', () => {
    expect(claimSubmissionSchema.safeParse({ ...claimInput, incidentDate: new Date('2026-06-02') }).success).toBe(false);
  });
  // Strict expected failures fail if the defect no longer reproduces.
  it.fails('BUG-001: rejects whitespace-only description as the backend does', () => {
    expect(claimSubmissionSchema.safeParse({ ...claimInput, description: ' '.repeat(10) }).success).toBe(false);
  });
  it.fails('BUG-001: rejects whitespace-only location as the backend does', () => {
    expect(claimSubmissionSchema.safeParse({ ...claimInput, incidentLocation: ' '.repeat(5) }).success).toBe(false);
  });
});
