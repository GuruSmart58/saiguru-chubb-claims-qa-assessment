import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { claimsApi } from '@/src/lib/api/bff-client';
import { useClaimWizardStore } from '@/src/features/claims/stores/use-claim-wizard-store';
import { claimInput, savedClaim, deferred } from './claim-fixture';

beforeEach(() => {
  useClaimWizardStore.getState().resetWizard();
  useClaimWizardStore.getState().updateFormData(claimInput);
});
afterEach(() => vi.restoreAllMocks());
it.fails('BUG-002: overlapping submit calls create at most one HTTP request', async () => {
  const pending = deferred<typeof savedClaim>();
  const submit = vi.spyOn(claimsApi, 'submitClaim').mockReturnValue(pending.promise);
  const first = useClaimWizardStore.getState().submitClaim();
  const second = useClaimWizardStore.getState().submitClaim();
  pending.resolve(savedClaim);
  await Promise.all([first, second]);
  expect(submit).toHaveBeenCalledTimes(1);
});
