import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import NewClaimPage from '@/app/(authenticated)/claims/new/page';
import { useClaimWizardStore } from '@/src/features/claims/stores/use-claim-wizard-store';
import { claimsApi } from '@/src/lib/api/bff-client';
import { ResponseError } from '@/src/lib/api/generated/runtime';
import { claimInput, savedClaim, deferred } from './claim-fixture';

const navigation = vi.hoisted(() => ({ push: vi.fn() }));
vi.mock('next/navigation', () => ({ useRouter: () => navigation }));
vi.mock('react-hot-toast', () => ({ default: { success: vi.fn(), error: vi.fn() } }));

// Real components, form validation and Zustand. Only network/navigation replaced.
describe('Claim wizard from the claimant perspective', () => {
  beforeEach(() => { useClaimWizardStore.getState().resetWizard(); vi.clearAllMocks(); });
  afterEach(() => { cleanup(); vi.restoreAllMocks(); });
  async function reachReview() {
    const user = userEvent.setup();
    render(<NewClaimPage />);
    expect(screen.getByRole('button', { name: 'Next' })).toBeDisabled();
    fireEvent.change(screen.getByLabelText(/When did the incident occur/), { target: { value: '2020-01-15' } });
    await user.type(screen.getByLabelText(/Where did the incident occur/), claimInput.incidentLocation);
    await user.type(screen.getByLabelText(/Claim Amount/), String(claimInput.claimAmount));
    await waitFor(() => expect(screen.getByRole('button', { name: 'Next' })).toBeEnabled());
    await user.click(screen.getByRole('button', { name: 'Next' }));
    await user.type(screen.getByLabelText(/Describe what happened/), claimInput.description);
    await user.click(screen.getByRole('button', { name: 'Next' }));
    expect(await screen.findByRole('heading', { name: 'Review Your Claim' })).toBeVisible();
    return user;
  }
  it('preserves edits on Back and submits the reviewed values once', async () => {
    const submit = vi.spyOn(claimsApi, 'submitClaim').mockResolvedValue(savedClaim);
    const user = await reachReview();
    await user.click(screen.getByRole('button', { name: 'Back' }));
    expect(screen.getByLabelText(/Describe what happened/)).toHaveValue(claimInput.description);
    await user.click(screen.getByRole('button', { name: 'Next' }));
    expect(screen.getByText('$2,500.50')).toBeVisible();
    await user.click(screen.getByRole('button', { name: 'Submit Claim' }));
    await waitFor(() => expect(navigation.push).toHaveBeenCalledWith('/claims'));
    expect(submit).toHaveBeenCalledExactlyOnceWith({ submitClaimRequest: claimInput });
    expect(useClaimWizardStore.getState().formData).toEqual({});
  });
  it('disables submission and Back while the server response is pending', async () => {
    const pending = deferred<typeof savedClaim>();
    const submit = vi.spyOn(claimsApi, 'submitClaim').mockReturnValue(pending.promise);
    const user = await reachReview();
    await user.click(screen.getByRole('button', { name: 'Submit Claim' }));
    expect(screen.getByRole('button', { name: 'Submitting...' })).toBeDisabled();
    expect(screen.getByRole('button', { name: 'Back' })).toBeDisabled();
    await user.click(screen.getByRole('button', { name: 'Submitting...' }));
    expect(submit).toHaveBeenCalledTimes(1);
    await act(async () => pending.resolve(savedClaim));
  });
  it('keeps entered data and permits retry after a network failure', async () => {
    const submit = vi.spyOn(claimsApi, 'submitClaim').mockRejectedValueOnce(new Error('offline')).mockResolvedValueOnce(savedClaim);
    const user = await reachReview();
    await user.click(screen.getByRole('button', { name: 'Submit Claim' }));
    expect(await screen.findByRole('alert')).toHaveTextContent('Failed to submit claim');
    expect(screen.getByText(claimInput.description)).toBeVisible();
    expect(navigation.push).not.toHaveBeenCalled();
    await user.click(screen.getByRole('button', { name: 'Submit Claim' }));
    await waitFor(() => expect(navigation.push).toHaveBeenCalledWith('/claims'));
    expect(submit).toHaveBeenCalledTimes(2);
  });
  it('shows server validation against the field after going back', async () => {
    vi.spyOn(claimsApi, 'submitClaim').mockRejectedValue(new ResponseError(new Response(JSON.stringify({
      detail: 'Description is invalid', fieldErrors: { description: 'Description must contain real text' },
    }), { status: 400 }), 'Validation failed'));
    const user = await reachReview();
    await user.click(screen.getByRole('button', { name: 'Submit Claim' }));
    expect(await screen.findByRole('alert')).toHaveTextContent('Description is invalid');
    await user.click(screen.getByRole('button', { name: 'Back' }));
    expect(await screen.findByRole('alert')).toHaveTextContent('Description must contain real text');
    expect(screen.getByLabelText(/Describe what happened/)).toHaveAttribute('aria-invalid', 'true');
  });
  it('requires confirmation before discarding a saved draft', async () => {
    const user = await reachReview();
    await user.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(screen.getByRole('dialog', { name: 'Cancel Claim Submission?' })).toBeVisible();
    await user.click(screen.getByRole('button', { name: 'Keep Editing' }));
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    expect(screen.getByText(claimInput.description)).toBeVisible();
    await user.click(screen.getByRole('button', { name: 'Cancel' }));
    await user.click(screen.getByRole('button', { name: 'Discard & Leave' }));
    expect(navigation.push).toHaveBeenCalledWith('/claims');
    expect(useClaimWizardStore.getState().formData).toEqual({});
  });
});
