import { describe, it, expect, beforeEach } from 'vitest';
import { useThemeStore } from '@/src/features/theme/stores/use-theme-store';

describe('useThemeStore', () => {
  beforeEach(() => {
    sessionStorage.clear();
    useThemeStore.setState({ theme: 'default', isDark: false });
  });

  it('has correct default state', () => {
    const state = useThemeStore.getState();
    expect(state.theme).toBe('default');
    expect(state.isDark).toBe(false);
  });

  it('setTheme updates theme to corporate', () => {
    useThemeStore.getState().setTheme('corporate');
    expect(useThemeStore.getState().theme).toBe('corporate');
  });

  it('setTheme updates theme to warm', () => {
    useThemeStore.getState().setTheme('warm');
    expect(useThemeStore.getState().theme).toBe('warm');
  });

  it('setTheme updates theme back to default', () => {
    useThemeStore.getState().setTheme('warm');
    useThemeStore.getState().setTheme('default');
    expect(useThemeStore.getState().theme).toBe('default');
  });

  it('toggleDark flips isDark from false to true', () => {
    useThemeStore.getState().toggleDark();
    expect(useThemeStore.getState().isDark).toBe(true);
  });

  it('toggleDark flips isDark from true to false', () => {
    useThemeStore.setState({ isDark: true });
    useThemeStore.getState().toggleDark();
    expect(useThemeStore.getState().isDark).toBe(false);
  });

  it('setTheme does not affect isDark', () => {
    useThemeStore.setState({ isDark: true });
    useThemeStore.getState().setTheme('corporate');
    expect(useThemeStore.getState().isDark).toBe(true);
    expect(useThemeStore.getState().theme).toBe('corporate');
  });

  it('toggleDark does not affect theme', () => {
    useThemeStore.getState().setTheme('warm');
    useThemeStore.getState().toggleDark();
    expect(useThemeStore.getState().theme).toBe('warm');
    expect(useThemeStore.getState().isDark).toBe(true);
  });

  it('persists theme to sessionStorage when changed', () => {
    useThemeStore.getState().setTheme('corporate');

    const stored = sessionStorage.getItem('theme-storage');
    expect(stored).toBeTruthy();

    const parsed = JSON.parse(stored!);
    expect(parsed.state.theme).toBe('corporate');
  });

  it('persists isDark to sessionStorage when toggled', () => {
    useThemeStore.getState().toggleDark();

    const stored = sessionStorage.getItem('theme-storage');
    expect(stored).toBeTruthy();

    const parsed = JSON.parse(stored!);
    expect(parsed.state.isDark).toBe(true);
  });

  it('restores theme from sessionStorage on initialization', () => {
    // Simulate stored state
    sessionStorage.setItem('theme-storage', JSON.stringify({
      state: { theme: 'warm', isDark: true },
      version: 0,
    }));

    useThemeStore.persist.rehydrate();
    expect(useThemeStore.getState().theme).toBe('warm');
    expect(useThemeStore.getState().isDark).toBe(true);
  });
});
