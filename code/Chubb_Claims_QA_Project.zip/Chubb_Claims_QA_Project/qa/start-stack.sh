#!/usr/bin/env bash
set -euo pipefail
QA_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
for tool in docker mvn java npm; do
  command -v "$tool" >/dev/null || { echo "Missing prerequisite: $tool" >&2; exit 1; }
done
docker compose version >/dev/null
(cd "$QA_ROOT/code/demo-app-ui" && npm ci && npm run generate:api)
"$QA_ROOT/start-infra.sh"
mvn -f "$QA_ROOT/code/claims-service/pom.xml" package -Dmaven.test.skip=true -Dcheckstyle.skip -Dpmd.skip
mvn -f "$QA_ROOT/code/bff-service/pom.xml" package -Dmaven.test.skip=true -Dcheckstyle.skip -Dpmd.skip
docker compose -f "$QA_ROOT/docker-compose.apps.yml" -f "$QA_ROOT/docker-compose.qa.yml" up --build -d --wait --wait-timeout 180
printf 'Stack started. Run npm run test:e2e in code/demo-app-ui.\n'
